# Quality rules

Common init ships `coding-style.md` (language-agnostic Critical). Stack-specific
quality rules arrive via the `langs/` rewrite on apply. This project applied `java`,
so [java-coding-style.md](java-coding-style.md) is present and replaces the pack's
generic Java style with the team's agreed rules.
