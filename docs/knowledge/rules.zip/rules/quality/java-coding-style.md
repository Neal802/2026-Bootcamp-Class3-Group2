# java-coding-style — Java 编码风格（本项目团队约定）

## Metadata

| Field | Value |
|---|---|
| **ID** | java-coding-style |
| **Category** | quality |
| **Priority** | High |
| **Activation** | auto |
| **Applies To** | all |
| **Stack** | java |

## Rule

### 包名

包名全部使用小写字母，并按业务或模块划分。

```java
package training.quote;
```

### 命名

| 对象 | 命名方式 | 示例 |
|---|---|---|
| 类、接口、Record | `UpperCamelCase` | `QuoteCalculator`、`QuotePrinter` |
| 方法、变量 | `lowerCamelCase` | `calculate`、`memberPrice` |
| 布尔变量 | 表达明确状态 | `member`、`isMember`、`eligibleForFreeShipping` |
| 常量 | 全大写，下划线分隔 | `MEMBER_SHIPPING_THRESHOLD` |
| 包名 | 全小写 | `training.quote` |

名称必须表达业务含义，禁止含义模糊的命名：

```java
// 不推荐
BigDecimal value;
BigDecimal result;
boolean flag;

// 推荐
BigDecimal originalPrice;
BigDecimal promotion;
BigDecimal shipping;
boolean member;
```

### 金额处理（CRITICAL）

- 金额统一使用 `BigDecimal`，禁止使用 `double` 或 `float` 处理货币。
- 金额常量统一通过项目提供的 `Money.amount` 创建。
- 金额比较统一使用 `compareTo`，禁止使用 `equals` 判断数值是否相等（`BigDecimal.equals` 同时比较数值和 scale）。

```java
private static final BigDecimal SHIPPING_AMOUNT = Money.amount("10.00");
private static final BigDecimal ZERO_AMOUNT = Money.amount("0.00");

if (goods.compareTo(MEMBER_SHIPPING_THRESHOLD) >= 0) {
    // 达到会员免运费门槛
}
```

### 常量

- 仅供当前类内部使用的常量使用 `private static final`。
- 只有属于明确的对外契约、且确实需要被其他类引用时才使用 `public static final`。

```java
private static final BigDecimal MEMBER_SHIPPING_THRESHOLD = Money.amount("80.00");
private static final BigDecimal NON_MEMBER_SHIPPING_THRESHOLD = Money.amount("100.00");
```

### 空行和代码布局

- 字段、构造方法、公共方法、私有方法之间保留一个空行。
- 同一逻辑步骤内部不要加入过多空行。
- 不为了视觉对齐添加不稳定的额外空格。
- 一个方法保持单一职责；当方法包含多个可独立命名的业务步骤时，提取私有方法。

### 业务表达：计算顺序必须清晰

`QuoteCalculator` 的计算流程应能从代码中直接识别：

1. 处理零金额等特殊输入。
2. 计算会员价。
3. 根据会员价计算促销减免。
4. 计算促销后的商品金额。
5. 根据商品金额和会员身份计算运费。
6. 计算最终总价。

```java
public Quote calculate(BigDecimal original, boolean member) {
    if (original.signum() == 0) {
        return new Quote(
                original,
                ZERO_AMOUNT,
                ZERO_AMOUNT,
                ZERO_AMOUNT,
                ZERO_AMOUNT,
                ZERO_AMOUNT
        );
    }

    BigDecimal memberPrice = Money.memberPrice(original, member);
    BigDecimal promotion = calculatePromotion(memberPrice);
    BigDecimal goods = memberPrice.subtract(promotion);
    BigDecimal shipping = calculateShipping(goods, member);
    BigDecimal total = goods.add(shipping);

    return new Quote(original, memberPrice, promotion, goods, shipping, total);
}
```

### 方法命名

计算型方法优先使用 `calculate`，避免使用容易被理解为普通属性访问的 `get`。若团队已统一使用 `getPromotion`、`getShipping`，可以保留，但同一项目内不得混用两种风格。

```java
calculatePromotion(memberPrice)
calculateShipping(goods, member)
```

### 三元表达式

简单的二选一可以使用三元表达式：

```java
return goods.compareTo(threshold) >= 0
        ? ZERO_AMOUNT
        : SHIPPING_AMOUNT;
```

涉及多个业务等级时，禁止多层嵌套三元表达式，改为从最高阈值到最低阈值的提前返回：

```java
// 不推荐
return memberPrice.compareTo(PROMOTION_LEVEL_3) >= 0 ? PROMOTION_LEVEL_3_AMOUNT :
        memberPrice.compareTo(PROMOTION_LEVEL_2) >= 0 ? PROMOTION_LEVEL_2_AMOUNT :
        memberPrice.compareTo(PROMOTION_LEVEL_1) >= 0 ? PROMOTION_LEVEL_1_AMOUNT : ZERO_AMOUNT;

// 推荐
private static BigDecimal calculatePromotion(BigDecimal memberPrice) {
    if (memberPrice.compareTo(PROMOTION_LEVEL_3) >= 0) {
        return PROMOTION_LEVEL_3_AMOUNT;
    }
    if (memberPrice.compareTo(PROMOTION_LEVEL_2) >= 0) {
        return PROMOTION_LEVEL_2_AMOUNT;
    }
    if (memberPrice.compareTo(PROMOTION_LEVEL_1) >= 0) {
        return PROMOTION_LEVEL_1_AMOUNT;
    }
    return ZERO_AMOUNT;
}
```

理由：阅读方向清楚、便于增删促销等级、便于断点和调试、突出业务规则而非表达式技巧。

### 运费逻辑与金额字段含义

运费门槛必须明确基于哪个金额判断。本项目运费基于会员折扣和促销减免后的 `goods` 判断。

```java
private static BigDecimal calculateShipping(BigDecimal goods, boolean member) {
    BigDecimal threshold = member
            ? MEMBER_SHIPPING_THRESHOLD
            : NON_MEMBER_SHIPPING_THRESHOLD;

    return goods.compareTo(threshold) >= 0
            ? ZERO_AMOUNT
            : SHIPPING_AMOUNT;
}
```

参数名必须体现语义，禁止 `calculateShipping(BigDecimal price, boolean member)`。

| 字段 | 含义 |
|---|---|
| `originalPrice` | 商品原价，即 `calculate` 的输入金额 |
| `memberPrice` | 会员折扣后的金额 |
| `promotion` | 促销减免金额 |
| `goods` | 会员折扣及促销减免后的商品金额 |
| `shipping` | 运费 |
| `total` | 最终支付金额 |

促销门槛基于 `memberPrice`，运费门槛基于 `goods`；`originalPrice` 是外部输入，不一定是最终用于门槛判断的金额。

### 注释

注释解释"为什么"，用于说明关键业务规则、阈值基于哪个中间金额判断、特殊边界条件、无法从代码直接看出的设计原因。

```java
// 不推荐
// 获取会员价格
BigDecimal memberPrice = Money.memberPrice(original, member);

// 推荐
// 运费门槛基于会员折扣和促销减免后的商品金额判断。
BigDecimal shipping = calculateShipping(goods, member);
```

```java
/**
 * 根据促销后的商品金额判断是否收取运费。
 * 会员满 80 元免运费，非会员满 100 元免运费。
 *
 * @param goods  会员折扣和促销减免后的商品金额
 * @param member 是否为会员
 * @return 应收取的运费
 */
private static BigDecimal calculateShipping(BigDecimal goods, boolean member) {
    // implementation
}
```

禁止在最终代码中保留流水账式编号注释（`// 1. 判断金额是否为 0`、`// 2. 获取会员价格` …）。练习初期可临时使用，重构完成后删除或改写为解释业务原因的注释。

### 补充：通用 Java 约定（沿用 pack 默认，未被本团队约定覆盖时适用）

- 值对象优先使用 `record`；字段默认 `final`。
- `Optional<T>` 仅用于可能无结果的查找方法返回值，禁止作为字段类型和方法参数。
- 领域异常继承 `RuntimeException` 且消息包含上下文；避免在非顶层处理处 `catch (Exception e)`。
- 流式操作保持短管道，复杂逻辑优先使用循环。

## Rationale

统一的 Java 风格约定让团队与 agent 产出的代码在命名、金额精度、常量可见性和业务表达上保持一致；金额使用 `BigDecimal` 与 `compareTo` 是为了避免浮点误差和 scale 比较陷阱。

## Verification

| Check | Blocks |
|---|---|
| 金额是否全部为 `BigDecimal` 且由 `Money.amount` 构造；金额比较是否使用 `compareTo` | pr-merge |
| 是否消除了魔法数字、多层嵌套三元表达式，阈值是否使用正确的中间金额字段 | pr-merge |
| 命名是否表达业务含义；内部常量是否优先 `private static final` | pr-merge |
| 注释是否解释业务原因，是否残留流水账编号注释和调试代码 | pr-merge |

## Examples

Good / Bad 对照见 Rule 段各小节中的 `// 推荐` 与 `// 不推荐` 代码块。

## Exceptions

- 本文件替换 rulepack 默认 `java-coding-style` 中与本团队约定重叠的部分；未被本节覆盖的通用约定仍按 pack 默认为准。
- 若团队改用 `getPromotion` / `getShipping` 命名，须整体统一，不得与 `calculate*` 混用。
