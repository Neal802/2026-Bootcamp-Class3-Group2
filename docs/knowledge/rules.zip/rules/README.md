# Rules knowledge

规则权威区，按 MECE 分类组织。Host 侧规则文件（如 `.qoder/rules/ai4se/`）是派生副本，冲突时以本目录为准。

| Category | 用途 |
|---|---|
| `process/` | spec-first、TDD 循环、提交规范、评审清单 |
| `architecture/` | 分层边界、无循环依赖、编排与执行分离 |
| `quality/` | 语言无关编码风格 + 栈相关编码风格 |
| `testing/` | 测试命名、结构、断言与边界值 |
| `security/` | 安全检查基线 |
| `documentation/` | 文档规范 |
| `modules/<id>/` | 单模块覆盖规则（仅在确有需要时创建） |

元数据格式与必需章节见 [_SCHEMA.md](_SCHEMA.md)；`_INDEX.md` 由 `scripts/kb-lint.sh` 编译，`_LOG.md` 只追加。

## 团队 Code Style（Java 练习项目）

以下规则由团队既有《Code Style Guide》拆分而来，是该文档在本仓库的权威落点：

| 规则 | 覆盖内容 |
|---|---|
| [quality/java-coding-style.md](quality/java-coding-style.md) | 包名、命名、金额（`BigDecimal` 与 `Money.amount`）、常量、代码布局、业务计算顺序、二元/嵌套条件、运费门槛字段、注释与 JavaDoc |
| [testing/java-testing.md](testing/java-testing.md) | 测试类与方法命名（`in_*_out_*`）、Given / When / Then、`assertAll` 断言顺序、边界值、完整测试示例 |
| [process/tdd-cycle.md](process/tdd-cycle.md) | Red / Green / Refactor 循环与各阶段验证要求 |
| [process/git-commit-conventions.md](process/git-commit-conventions.md) | spec 级提交时机（verify / archive 各一次）、`<type>(<stage>): <change-id> <description>` 格式、提交前验证 |
| [process/code-review-checklist.md](process/code-review-checklist.md) | 生产代码、测试代码、TDD 与 Git 三段评审清单 |

引用方式：在评审意见、提交说明或 `AGENTS.md` 中使用 `@rule:<id>` 指针，不要复制规则正文。
