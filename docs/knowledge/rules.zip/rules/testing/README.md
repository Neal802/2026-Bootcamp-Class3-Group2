# Testing rules

Common init ships this index only. Add testing rules here as the project adopts ATDD/CI gates.
This project applied `java`, so [java-testing.md](java-testing.md) holds the team's
JUnit 5 naming, structure, assertion-order and boundary-value rules.
