# Rules change log

| date | id | change | author |
|---|---|---|---|
| 2026-11-10 | rules-init | `/sdd:rules-govern --mode init --langs java` 生成 MECE 骨架（common 15 + java 5） | agent |
| 2026-11-10 | java-coding-style | 以团队《Code Style Guide》§2–§4 替换 pack 默认 Java 编码风格（命名、金额、常量、布局、业务表达、注释） | agent |
| 2026-11-10 | java-testing | 以团队 §5–§8、§11 替换 pack 默认 Java 测试规则（`in_*_out_*` 命名、Given / When / Then、`assertAll`、边界值） | agent |
| 2026-11-10 | tdd-cycle | 新增 Red / Green / Refactor 循环规则（Critical，取自 §9） | agent |
| 2026-11-10 | git-commit-conventions | 新增小步提交、`<type>(<phase>): <description>` 与提交前验证规则（取自 §10） | agent |
| 2026-11-10 | code-review-checklist | 新增生产代码 / 测试代码 / TDD 与 Git 三段评审清单（取自 §12） | agent |
| 2026-11-10 | git-commit-conventions | **提交时机改为 spec 级**：一个 change 在 `/opsx verify` 通过后、`/opsx archive` 之后各提交一次；格式改为 `<type>(<stage>): <change-id> <description>`；Priority 升为 Critical。取代原「按 TDD 步骤小步提交」 | agent |
| 2026-11-10 | tdd-cycle | 移除「Red / Green / Refactor 分别提交」表述，改为不提交的工作纪律；Red 证据转由 verify 报告承载；新增「未在 verify 前提交中间态」检查项 | agent |
| 2026-11-10 | code-review-checklist | TDD 与 Git 段改为校验 spec 级两次提交与 message 格式，新增「无 TDD 中间提交」「archive 提交范围」检查项 | agent |
